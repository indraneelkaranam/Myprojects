module.exports = {
    database: 'mongodb://localhost:27017/hello', 
    secret: 'yoursecret'
  }
  